<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="System School" />
    <meta name="description" content="Dashboard Teacher" />
    <meta name="author" content="amira ali" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <?php echo $__env->make('layouts.teacher.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
    <div class="wrapper">
        <div id="pre-loader">
            <img src="<?php echo e(URL::asset('assets/images/pre-loader/loader-01.svg')); ?>" alt="">
        </div>
        <?php echo $__env->make('layouts.teacher.main-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layouts.teacher.main-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--Main content -->
        <!-- main-content -->
        <div class="content-wrapper" style="width: 81%">
            <div class="page-title">
                <div class="row">
                    <div class="col-sm-6">
                        <h4 class="mb-4"><?php echo e(trans('main_trans.Welcome')); ?> : <?php echo e(auth()->user()->name); ?></h4>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb pt-0 pr-0 float-left float-sm-right">
                        </ol>
                    </div>
                </div>
            </div>
            <!-- widgets -->
            <div class="row">
                <div class="col-xl-6 col-lg-6 col-md-6 mb-30">
                    <div class="card card-statistics h-100">
                        <div class="card-body">
                            <div class="clearfix">
                                <div class="float-left">
                                    <span class="text-danger">
                                        <i class="fas fa-user-graduate highlight-icon" aria-hidden="true"></i>
                                    </span>
                                </div>
                                <div class="float-right text-right">
                                    <p class="card-text text-dark"><?php echo e(trans('main_trans.cont_student')); ?></p>
                                    <h4><?php echo e($count_students); ?></h4>
                                </div>
                            </div>
                            <p class="text-muted pt-3 mb-0 mt-2 border-top">
                                <i class="fas fa-binoculars mr-1" aria-hidden="true"></i><a href="<?php echo e(route('student')); ?>"><span class="text-danger"><?php echo e(trans('main_trans.display')); ?></span></a>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 col-lg-6 col-md-6 mb-30">
                    <div class="card card-statistics h-100">
                        <div class="card-body">
                            <div class="clearfix">
                                <div class="float-left">
                                    <span class="text-primary">
                                        <i class="fas fa-chalkboard highlight-icon" aria-hidden="true"></i>
                                    </span>
                                </div>
                                <div class="float-right text-right">
                                    <p class="card-text text-dark"><?php echo e(trans('main_trans.cont_section')); ?></p>
                                    <h4><?php echo e($count_sections); ?></h4>
                                </div>
                            </div>
                            <p class="text-muted pt-3 mb-0 mt-2 border-top">
                                <i class="fas fa-binoculars mr-1" aria-hidden="true"></i><a href="<?php echo e(route('section')); ?>" target="_blank"><span class="text-danger"><?php echo e(trans('main_trans.display')); ?></span></a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Orders Status widgets-->
            <div class="row">
                <div class="col-xl-12 mb-30">
                    <div class="card card-statistics h-100">
                        <div class="card-body">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('calendar', [])->html();
} elseif ($_instance->childHasBeenRendered('okq8QiE')) {
    $componentId = $_instance->getRenderedChildComponentId('okq8QiE');
    $componentTag = $_instance->getRenderedChildComponentTagName('okq8QiE');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('okq8QiE');
} else {
    $response = \Livewire\Livewire::mount('calendar', []);
    $html = $response->html();
    $_instance->logRenderedChild('okq8QiE', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            <h1 class="mb-4"></h1>
                        </div>
                    </div>
                </div>
            </div>

            <!--footer -->
            <?php echo $__env->make('layouts.teacher.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div><!-- main content wrapper end-->
    </div>
    </div>
    </div>
    <!--footer -->
    <?php echo $__env->make('layouts.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH F:\Projects\laravel\School_System\resources\views/dashboardTeacher/dashboard.blade.php ENDPATH**/ ?>
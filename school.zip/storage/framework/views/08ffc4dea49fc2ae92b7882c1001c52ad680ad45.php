<?php $__env->startSection('css'); ?>
    @toastr_css
<?php $__env->startSection('title'); ?>
<?php echo e(trans('fee_trans.add_fee')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<div class="page-title">
    <div class="row">
        <div class="col-sm-6">
            <h4 class="mb-0"><?php echo e(trans('fee_trans.add_fee')); ?></h4>
        </div>
        <div class="col-sm-6">
            <ol class="breadcrumb pt-0 pr-0 float-left float-sm-right ">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>" class="default-color"><?php echo e(trans('main_trans.main')); ?></a></li>
                <li class="breadcrumb-item active"><?php echo e(trans('fee_trans.add_fee')); ?></li>
            </ol>
        </div>
    </div>
</div>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- row -->
    <div class="row">
        <div class="col-md-12 mb-30">
            <div class="card card-statistics h-100">
                <div class="card-body">

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                        <form class="row mb-30" action="<?php echo e(route('fees_student.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="card-body">
                                <div class="repeater">
                                    <div >
                                        <div data-repeater-item>
                                            <div class="row">

                                                <div class="col">
                                                    <label for="name" class="mr-sm-2"><?php echo e(trans('fee_trans.name_student')); ?></label>
                                                    <div class="box">
                                                        <input type="hidden" name="student_id" value="<?php echo e($student->id); ?>">
                                                        <input type="text" value="<?php echo e($student->name); ?>" readonly>
                                                    </div>
                                                </div>

                                                <div class="col">
                                                    <label for="" class="mr-sm-2"><?php echo e(trans('fee_trans.Fee_type')); ?></label>
                                                    <div class="box">
                                                        <select class="fancyselect" name="fee_id" required>
                                                            <option><?php echo e(trans('fee_trans.Choose')); ?></option>
                                                            <?php $__currentLoopData = $fees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($fee->id); ?>"><?php echo e($fee->title); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>

                                                </div>

                                                <div class="col">
                                                    <label for="" class="mr-sm-2"><?php echo e(trans('fee_trans.amount')); ?></label>
                                                    <div class="box" >
                                                        <select class="fancyselect"  name="amount" required>
                                                            <option><?php echo e(trans('fee_trans.Choose')); ?></option>
                                                            <?php $__currentLoopData = $fees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($fee->id); ?>"><?php echo e($fee->amount); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col">
                                                    <label for="description" class="mr-sm-2"><?php echo e(trans('fee_trans.Notes')); ?></label>
                                                    <div class="box">
                                                        <input type="text" class="form-control" name="description" >
                                                    </div>
                                                </div>


                                            </div>
                                        </div>
                                    </div>
                                    <br>
                                    <input type="hidden" name="level_id" value="<?php echo e($student->level_id); ?>">
                                    <input type="hidden" name="classroom_id" value="<?php echo e($student->classroom_id); ?>">

                                    <button type="submit" class="btn btn-primary btn-lg"><?php echo e(trans('fee_trans.submit')); ?></button>
                                </div>
                            </div>
                        </form>

                </div>
            </div>
        </div>
    </div>
    <!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    @toastr_js
    @toastr_render

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\laravel\School_System\resources\views/fee-student/create.blade.php ENDPATH**/ ?>
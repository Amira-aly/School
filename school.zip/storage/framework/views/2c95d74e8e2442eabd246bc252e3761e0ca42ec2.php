<?php $__env->startSection('css'); ?>
    <?php $__env->startSection('title'); ?>
    <?php echo e(trans('main_trans.Attendance_reports')); ?>

    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
    <?php $__env->startSection('content'); ?>
        <!-- row -->
        <div class="row">
            <div class="col-md-12 mb-30">
                <div class="card card-statistics h-100">
                    <div class="card-body">

                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <form method="POST"  action="<?php echo e(route('sons.attendance.search')); ?>" autocomplete="off">
                            <?php echo csrf_field(); ?>
                            <h6 style="font-family: 'Cairo', sans-serif;color: blue"><?php echo e(trans('main_trans.Search_information')); ?></h6><br>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="student"><?php echo e(trans('main_trans.student')); ?></label>
                                        <select class="custom-select mr-sm-2" name="student_id">
                                            <option value="0"><?php echo e(trans('main_trans.all')); ?></option>
                                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($student->id); ?>"><?php echo e($student->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="card-body datepicker-form">
                                    <div class="input-group" data-date-format="yyyy-mm-dd">
                                        <input type="text"  class="form-control range-from date-picker-default" placeholder="Start Date" required name="from">
                                        <span class="input-group-addon"><?php echo e(trans('main_trans.To_date')); ?></span>
                                        <input class="form-control range-to date-picker-default" placeholder="End Date" type="text" required name="to">
                                    </div>
                                </div>

                            </div>
                            <button class="btn btn-success  nextBtn btn-lg pull-right" type="submit"  style="margin-bottom: 20px;"><?php echo e(trans('main_trans.search')); ?></button>
                        </form>
                        <?php if(isset($Students)): ?>
                            <div class="table-responsive">
                                <table id="datatable" class="table  table-hover table-sm table-bordered p-0" data-page-length="50"
                                       style="text-align: center">
                                    <thead>
                                    <tr>
                                        <th class="alert-success">#</th>
                                        <th class="alert-success"><?php echo e(trans('students_trans.name')); ?></th>
                                        <th class="alert-success"><?php echo e(trans('students_trans.Grade')); ?></th>
                                        <th class="alert-success"><?php echo e(trans('students_trans.section')); ?></th>
                                        <th class="alert-success"><?php echo e(trans('main_trans.date')); ?></th>
                                        <th class="alert-warning"><?php echo e(trans('Sections_trans.Status')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $Students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->index+1); ?></td>
                                            <td><?php echo e($student->student->name); ?></td>
                                            <td><?php echo e($student->level->name); ?></td>
                                            <td><?php echo e($student->section->name); ?></td>
                                            <td><?php echo e($student->attendence_date); ?></td>


                                            <?php if($student->attendence_status == 0): ?>
                                                <td class="btn-danger">
                                                    <?php echo e(trans('attendance_trans.absence')); ?>

                                                </td>
                                            <?php else: ?>
                                                <td class="btn-success">
                                                    <?php echo e(trans('attendance_trans.presence')); ?>

                                                </td>
                                            <?php endif; ?>

                                        </tr>
                                    <?php echo $__env->make('DashboardParent.Attendances.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
        <!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.parent.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\laravel\School_System\resources\views/DashboardParent/Attendances/index.blade.php ENDPATH**/ ?>
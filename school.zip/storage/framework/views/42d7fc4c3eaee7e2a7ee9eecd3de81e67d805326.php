<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="System School" />
    <meta name="description" content="Dashboard Admin" />
    <meta name="author" content="amira ali" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
    <div class="wrapper">
        <div id="pre-loader">
            <img src="assets/images/pre-loader/loader-01.svg" alt="">
        </div>
        <?php echo $__env->make('layouts.main-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layouts.admin.main-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--Main content -->
        <!-- main-content -->
        <div class="content-wrapper" style="width: 81%">
            <div class="page-title">
                <div class="row">
                    <div class="col-sm-6">
                        <h4 class="mb-4"><?php echo e(trans('main_trans.dashboard_abmin')); ?></h4>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb pt-0 pr-0 float-left float-sm-right">
                        </ol>
                    </div>
                </div>
            </div>
            <!-- widgets -->
            <div class="row">
                <div class="col-xl-3 col-lg-6 col-md-6 mb-30">
                    <div class="card card-statistics h-100">
                        <div class="card-body">
                            <div class="clearfix">
                                <div class="float-left">
                                    <span class="text-danger">
                                        <i class="fas fa-user-graduate highlight-icon" aria-hidden="true"></i>
                                    </span>
                                </div>
                                <div class="float-right text-right">
                                    <p class="card-text text-dark"><?php echo e(trans('main_trans.cont_student')); ?></p>
                                    <h4><?php echo e(\App\Models\Student::count()); ?></h4>
                                </div>
                            </div>
                            <p class="text-muted pt-3 mb-0 mt-2 border-top">
                                <i class="fas fa-binoculars mr-1" aria-hidden="true"></i><a href="<?php echo e(route('students.index')); ?>" target="_blank"><span class="text-danger"><?php echo e(trans('main_trans.display')); ?></span></a>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6 col-md-6 mb-30">
                    <div class="card card-statistics h-100">
                        <div class="card-body">
                            <div class="clearfix">
                                <div class="float-left">
                                    <span class="text-warning">
                                        <i class="fas fa-chalkboard-teacher highlight-icon" aria-hidden="true"></i>
                                    </span>
                                </div>
                                <div class="float-right text-right">
                                    <p class="card-text text-dark"><?php echo e(trans('main_trans.cont_teacher')); ?></p>
                                    <h4><?php echo e(\App\Models\Teacher::count()); ?></h4>
                                </div>
                            </div>
                            <p class="text-muted pt-3 mb-0 mt-2 border-top">
                                <i class="fas fa-binoculars mr-1" aria-hidden="true"></i><a href="<?php echo e(route('teachers.index')); ?>" target="_blank"><span class="text-danger"><?php echo e(trans('main_trans.display')); ?></span></a>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6 col-md-6 mb-30">
                    <div class="card card-statistics h-100">
                        <div class="card-body">
                            <div class="clearfix">
                                <div class="float-left">
                                    <span class="text-success">
                                        <i class="fas fa-user-tie highlight-icon" aria-hidden="true"></i>
                                    </span>
                                </div>
                                <div class="float-right text-right">
                                    <p class="card-text text-dark"><?php echo e(trans('main_trans.cont_parent')); ?></p>
                                    <h4><?php echo e(\App\Models\Parentt::count()); ?></h4>
                                </div>
                            </div>
                            <p class="text-muted pt-3 mb-0 mt-2 border-top">
                                <i class="fas fa-binoculars mr-1" aria-hidden="true"></i><a href="<?php echo e(route('add_parent')); ?>" target="_blank"><span class="text-danger"><?php echo e(trans('main_trans.display')); ?></span></a>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6 col-md-6 mb-30">
                    <div class="card card-statistics h-100">
                        <div class="card-body">
                            <div class="clearfix">
                                <div class="float-left">
                                    <span class="text-primary">
                                        <i class="fas fa-chalkboard highlight-icon" aria-hidden="true"></i>
                                    </span>
                                </div>
                                <div class="float-right text-right">
                                    <p class="card-text text-dark"><?php echo e(trans('main_trans.cont_section')); ?></p>
                                    <h4><?php echo e(\App\Models\Section::count()); ?></h4>
                                </div>
                            </div>
                            <p class="text-muted pt-3 mb-0 mt-2 border-top">
                                <i class="fas fa-binoculars mr-1" aria-hidden="true"></i><a href="<?php echo e(route('sections.index')); ?>" target="_blank"><span class="text-danger"><?php echo e(trans('main_trans.display')); ?></span></a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Orders Status widgets-->
            <div class="row">
                <div  style="height: 400px;" class="col-xl-12 mb-30">
                    <div class="card card-statistics h-100">
                        <div class="card-body">
                            <div class="tab nav-border" style="position: relative;">
                                <div class="d-block d-md-flex justify-content-between">
                                    <div class="d-block w-100">
                                        <h5 style="font-family: 'Cairo', sans-serif" class="card-title"><?php echo e(trans('main_trans.operations')); ?></h5>
                                    </div>
                                    <div class="d-block d-md-flex nav-tabs-custom">
                                        <ul class="nav nav-tabs" id="myTab" role="tablist">

                                            <li class="nav-item">
                                                <a class="nav-link active show" id="students-tab" data-toggle="tab"
                                                   href="#students" role="tab" aria-controls="students"
                                                   aria-selected="true"><?php echo e(trans('main_trans.student')); ?></a>
                                            </li>

                                            <li class="nav-item">
                                                <a class="nav-link" id="teachers-tab" data-toggle="tab" href="#teachers"
                                                   role="tab" aria-controls="teachers" aria-selected="false"><?php echo e(trans('main_trans.Teachers')); ?>

                                                </a>
                                            </li>

                                            <li class="nav-item">
                                                <a class="nav-link" id="parents-tab" data-toggle="tab" href="#parents"
                                                   role="tab" aria-controls="parents" aria-selected="false"><?php echo e(trans('main_trans.Parents')); ?>

                                                </a>
                                            </li>

                                            <li class="nav-item">
                                                <a class="nav-link" id="fee_invoices-tab" data-toggle="tab" href="#fee_invoices"
                                                   role="tab" aria-controls="fee_invoices" aria-selected="false"><?php echo e(trans('main_trans.invoices')); ?>

                                                </a>
                                            </li>

                                        </ul>
                                    </div>
                                </div>
                                <div class="tab-content" id="myTabContent">

                                    
                                    <div class="tab-pane fade active show" id="students" role="tabpanel" aria-labelledby="students-tab">
                                        <div class="table-responsive mt-15">
                                            <table style="text-align: center" class="table center-aligned-table table-hover mb-0">
                                                <thead>
                                                <tr  class="table-info text-danger">
                                                    <th>#</th>
                                                    <th><?php echo e(trans('students_trans.name')); ?></th>
                                                    <th><?php echo e(trans('students_trans.email')); ?></th>
                                                    <th><?php echo e(trans('students_trans.gender')); ?></th>
                                                    <th><?php echo e(trans('students_trans.Grade')); ?></th>
                                                    <th><?php echo e(trans('students_trans.classrooms')); ?></th>
                                                    <th><?php echo e(trans('students_trans.section')); ?></th>
                                                    <th><?php echo e(trans('students_trans.add_date')); ?></th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = \App\Models\Student::latest()->take(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <td><?php echo e($loop->iteration); ?></td>
                                                        <td><?php echo e($student->name); ?></td>
                                                        <td><?php echo e($student->email); ?></td>
                                                        <td><?php echo e($student->gender->name); ?></td>
                                                        <td><?php echo e($student->level->name); ?></td>
                                                        <td><?php echo e($student->classroom->name); ?></td>
                                                        <td><?php echo e($student->section->name); ?></td>
                                                        <td class="text-success"><?php echo e($student->created_at); ?></td>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            <td class="alert-danger" colspan="8"><?php echo e(trans('main_trans.no_data')); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                    
                                    <div class="tab-pane fade" id="teachers" role="tabpanel" aria-labelledby="teachers-tab">
                                        <div class="table-responsive mt-15">
                                            <table style="text-align: center" class="table center-aligned-table table-hover mb-0">
                                                <thead>
                                                <tr  class="table-info text-danger">
                                                    <th>#</th>
                                                    <th><?php echo e(trans('teacher_trans.Name_Teacher')); ?></th>
                                                    <th><?php echo e(trans('teacher_trans.Gender')); ?></th>
                                                    <th><?php echo e(trans('teacher_trans.Joining_Date')); ?></th>
                                                    <th><?php echo e(trans('teacher_trans.specialization')); ?></th>
                                                    <th><?php echo e(trans('students_trans.add_date')); ?></th>
                                                </tr>
                                                </thead>

                                                <?php $__empty_1 = true; $__currentLoopData = \App\Models\Teacher::latest()->take(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tbody>
                                                    <tr>
                                                        <td><?php echo e($loop->iteration); ?></td>
                                                        <td><?php echo e($teacher->name); ?></td>
                                                        <td><?php echo e($teacher->gender->name); ?></td>
                                                        <td><?php echo e($teacher->joining_date); ?></td>
                                                        <td><?php echo e($teacher->specialization->name); ?></td>
                                                        <td class="text-success"><?php echo e($teacher->created_at); ?></td>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            <td class="alert-danger" colspan="8"><?php echo e(trans('main_trans.no_data')); ?></td>
                                                    </tr>
                                                    </tbody>
                                                <?php endif; ?>
                                            </table>
                                        </div>
                                    </div>

                                    
                                    <div class="tab-pane fade" id="parents" role="tabpanel" aria-labelledby="parents-tab">
                                        <div class="table-responsive mt-15">
                                            <table style="text-align: center" class="table center-aligned-table table-hover mb-0">
                                                <thead>
                                                <tr  class="table-info text-danger">
                                                    <th>#</th>
                                                    <th><?php echo e(trans('parent_trans.name_father')); ?></th>
                                                    <th><?php echo e(trans('parent_trans.Email')); ?></th>
                                                    <th><?php echo e(trans('parent_trans.National_ID_Father')); ?></th>
                                                    <th><?php echo e(trans('parent_trans.Phone_Father')); ?></th>
                                                    <th><?php echo e(trans('students_trans.add_date')); ?></th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = \App\Models\Parentt::latest()->take(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <td><?php echo e($loop->iteration); ?></td>
                                                        <td><?php echo e($parent->name_father); ?></td>
                                                        <td><?php echo e($parent->email); ?></td>
                                                        <td><?php echo e($parent->nationality_father_id); ?></td>
                                                        <td><?php echo e($parent->phone_father); ?></td>
                                                        <td class="text-success"><?php echo e($parent->created_at); ?></td>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            <td class="alert-danger" colspan="8"><?php echo e(trans('main_trans.no_data')); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                    
                                    <div class="tab-pane fade" id="fee_invoices" role="tabpanel" aria-labelledby="fee_invoices-tab">
                                        <div class="table-responsive mt-15">
                                            <table style="text-align: center" class="table center-aligned-table table-hover mb-0">
                                                <thead>
                                                <tr  class="table-info text-danger">
                                                    <th>#</th>
                                                    <th><?php echo e(trans('fee_trans.invoice_date')); ?></th>
                                                    <th><?php echo e(trans('fee_trans.name_student')); ?></th>
                                                    <th><?php echo e(trans('fee_trans.level')); ?></th>
                                                    <th><?php echo e(trans('fee_trans.classroom')); ?></th>
                                                    <th><?php echo e(trans('students_trans.section')); ?></th>
                                                    <th><?php echo e(trans('fee_trans.Fee_type')); ?></th>
                                                    <th><?php echo e(trans('fee_trans.amount')); ?></th>
                                                    <th><?php echo e(trans('students_trans.add_date')); ?></th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = \App\Models\Fee_invoice::latest()->take(10)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <td><?php echo e($loop->iteration); ?></td>
                                                        <td><?php echo e($section->invoice_date); ?></td>
                                                        <td><?php echo e($section->classroom->name); ?></td>
                                                        <td class="text-success"><?php echo e($section->created_at); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td class="alert-danger" colspan="9"><?php echo e(trans('main_trans.no_data')); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('calendar', [])->html();
} elseif ($_instance->childHasBeenRendered('pNNImbP')) {
    $componentId = $_instance->getRenderedChildComponentId('pNNImbP');
    $componentTag = $_instance->getRenderedChildComponentTagName('pNNImbP');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('pNNImbP');
} else {
    $response = \Livewire\Livewire::mount('calendar', []);
    $html = $response->html();
    $_instance->logRenderedChild('pNNImbP', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <h1 class="mb-4"></h1>
            <!--footer -->
            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div><!-- main content wrapper end-->
    </div>
    </div>
    </div>
    <!--footer -->
    <?php echo $__env->make('layouts.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH F:\Projects\laravel\School_System\resources\views/dashboard.blade.php ENDPATH**/ ?>
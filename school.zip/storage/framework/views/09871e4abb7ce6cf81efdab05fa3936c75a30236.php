<?php $__env->startSection('css'); ?>
    @toastr_css
<?php $__env->startSection('title'); ?>
    <?php echo e(trans('fee_trans.Invoices')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<div class="page-title">
    <div class="row">
        <div class="col-sm-6">
            <h4 class="mb-0"><?php echo e(trans('fee_trans.Invoices')); ?></h4>
        </div>
        <div class="col-sm-6">
            <ol class="breadcrumb pt-0 pr-0 float-left float-sm-right ">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>" class="default-color"><?php echo e(trans('main_trans.main')); ?></a></li>
                <li class="breadcrumb-item active"><?php echo e(trans('fee_trans.Invoices')); ?></li>
            </ol>
        </div>
    </div>
</div>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- row -->
    <div class="row">
        <div class="col-md-12 mb-30">
            <div class="card card-statistics h-100">
                <div class="card-body">
                    <div class="col-xl-12 mb-30">
                        <div class="card card-statistics h-100">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="datatable" class="table  table-hover table-sm table-bordered p-0"
                                           data-page-length="50"
                                           style="text-align: center">
                                        <thead>
                                        <tr class="alert-success">
                                            <th>#</th>
                                            <th><?php echo e(trans('fee_trans.name')); ?></th>
                                            <th><?php echo e(trans('fee_trans.Fee_type')); ?></th>
                                            <th><?php echo e(trans('fee_trans.amount')); ?></th>
                                            <th><?php echo e(trans('fee_trans.level')); ?></th>
                                            <th><?php echo e(trans('fee_trans.classroom')); ?></th>
                                            <th><?php echo e(trans('fee_trans.statement')); ?></th>
                                            <th><?php echo e(trans('fee_trans.Processes')); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $fee_invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fee_invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($fee_invoice->student->name); ?></td>
                                            <td><?php echo e($fee_invoice->fee->title); ?></td>
                                            <td><?php echo e(number_format($fee_invoice->amount,2)); ?></td>
                                            <td><?php echo e($fee_invoice->level->name); ?></td>
                                            <td><?php echo e($fee_invoice->classroom->name); ?></td>
                                            <td><?php echo e($fee_invoice->description); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('fees_student.edit',$fee_invoice->id)); ?>" class="btn btn-info btn-sm" role="button" aria-pressed="true"><i class="fa fa-edit"></i></a>
                                                    <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#" ><i class="fa fa-trash"></i></button>
                                                </td>
                                            </tr>
                                            <?php echo $__env->make('fee-student.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    @toastr_js
    @toastr_render
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\laravel\School_System\resources\views/fee-student/index.blade.php ENDPATH**/ ?>
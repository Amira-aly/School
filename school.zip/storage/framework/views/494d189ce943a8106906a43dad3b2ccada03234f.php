<?php $__env->startSection('css'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

    <?php $__env->startSection('title'); ?>
        <?php echo e(trans('exam_trans.make_exam')); ?>

    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('show-question', ['exam_id' => $exam_id, 'student_id' => $student_id])->html();
} elseif ($_instance->childHasBeenRendered('RTmhNBU')) {
    $componentId = $_instance->getRenderedChildComponentId('RTmhNBU');
    $componentTag = $_instance->getRenderedChildComponentTagName('RTmhNBU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('RTmhNBU');
} else {
    $response = \Livewire\Livewire::mount('show-question', ['exam_id' => $exam_id, 'student_id' => $student_id]);
    $html = $response->html();
    $_instance->logRenderedChild('RTmhNBU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.student.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\laravel\School_System\resources\views/DashboardStudent/exams/show.blade.php ENDPATH**/ ?>
<?php $__env->startSection('css'); ?>
    @toastr_css
<?php $__env->startSection('title'); ?>
<?php echo e(trans('exam_trans.edit_exam')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
 <!-- breadcrumb -->
 <div class="page-title">
    <div class="row">
        <div class="col-sm-6">
            <h4 class="mb-0"><?php echo e(trans('exam_trans.edit_exam')); ?> <?php echo e($exam->name); ?></h4>
        </div>
        <div class="col-sm-6">
            <ol class="breadcrumb pt-0 pr-0 float-left float-sm-right ">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/teacher/dashboard')); ?>" class="default-color"><?php echo e(trans('main_trans.main')); ?></a></li>
                <li class="breadcrumb-item active"><?php echo e(trans('exam_trans.edit_exam')); ?></li>
            </ol>
        </div>
    </div>
</div>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- row -->
    <div class="row">
        <div class="col-md-12 mb-30">
            <div class="card card-statistics h-100">
                <div class="card-body">

                    <?php if(session()->has('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong><?php echo e(session()->get('error')); ?></strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <div class="col-xs-12">
                        <div class="col-md-12">
                            <br>
                            <form action="<?php echo e(route('exams.update','test')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="form-row">

                                    <div class="col">
                                        <label ><?php echo e(trans('exam_trans.exam_name_ar')); ?></label>
                                        <input type="text" name="name" value="<?php echo e($exam->getTranslation('name','ar')); ?>" class="form-control" required>
                                        <input type="hidden" name="id" value="<?php echo e($exam->id); ?>">
                                    </div>

                                    <div class="col">
                                        <label ><?php echo e(trans('exam_trans.exam_name_en')); ?></label>
                                        <input type="text" name="name_en" value="<?php echo e($exam->getTranslation('name','en')); ?>" class="form-control" required>
                                    </div>
                                </div>
                                <br>

                                <div class="form-row">

                                    <div class="col">
                                        <div class="form-group">
                                            <label for="subject_id"><?php echo e(trans('exam_trans.subject_name')); ?> : <span class="text-danger">*</span></label>
                                            <select class="custom-select mr-sm-2" name="subject_id">
                                                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($subject->id); ?>" <?php echo e($subject->id == $exam->subject_id ? "selected":""); ?>><?php echo e($subject->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                </div>

                                <div class="form-row">

                                    <div class="col">
                                        <div class="form-group">
                                            <label for="level_id"><?php echo e(trans('exam_trans.level')); ?> : <span class="text-danger">*</span></label>
                                            <select class="custom-select mr-sm-2" name="level_id" required>
                                                <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option  value="<?php echo e($level->id); ?>" <?php echo e($level->id == $exam->level_id ? "selected":""); ?>><?php echo e($level->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col">
                                        <div class="form-group">
                                            <label for="classroom_id"><?php echo e(trans('exam_trans.classroom')); ?> : <span class="text-danger">*</span></label>
                                            <select class="custom-select mr-sm-2" name="classroom_id" required>
                                                <option value="<?php echo e($exam->classroom_id); ?>"><?php echo e($exam->classroom->name); ?></option>                                            </select>
                                        </div>
                                    </div>

                                    <div class="col">
                                        <div class="form-group">
                                            <label for="section_id"><?php echo e(trans('exam_trans.sections')); ?> : </label>
                                            <select class="custom-select mr-sm-2" name="section_id" required>
                                                <option value="<?php echo e($exam->section_id); ?>"><?php echo e($exam->section->name); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                </div><br>
                                <button class="btn btn-success nextBtn btn-lg pull-right" type="submit"><?php echo e(trans('exam_trans.edit')); ?></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    @toastr_js
    @toastr_render
    <script>
        $(document).ready(function () {
            $('select[name="level_id"]').on('change', function () {
                var level_id = $(this).val();
                if (level_id) {
                    $.ajax({
                        url: "<?php echo e(URL::to('Get_classroomss')); ?>/" + level_id,
                        type: "GET",
                        dataType: "json",
                        success: function (data) {
                            $('select[name="classroom_id"]').empty();
                            $('select[name="classroom_id"]').append('<option selected disabled ><?php echo e(trans('parent_trans.Choose')); ?>...</option>');
                            $.each(data, function (key, value) {
                                $('select[name="classroom_id"]').append('<option value="' + key + '">' + value + '</option>');
                            });
                        },
                    });
                } else {
                    console.log('AJAX load did not work');
                }
            });
        });
    </script>
    <script>
        $(document).ready(function () {
            $('select[name="classroom_id"]').on('change', function () {
                var classroom_id = $(this).val();
                if (classroom_id) {
                    $.ajax({
                        url: "<?php echo e(URL::to('Get_Sectionss')); ?>/" + classroom_id,
                        type: "GET",
                        dataType: "json",
                        success: function (data) {
                            $('select[name="section_id"]').empty();
                            $('select[name="section_id"]').append('<option selected disabled ><?php echo e(trans('parent_trans.Choose')); ?>...</option>');
                            $.each(data, function (key, value) {
                                $('select[name="section_id"]').append('<option value="' + key + '">' + value + '</option>');
                            });
                        },
                    });
                }
                else {
                    console.log('AJAX load did not work');
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.teacher.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\laravel\School_System\resources\views/DashboardTeacher/exams/edit.blade.php ENDPATH**/ ?>
<?php $__env->startSection('css'); ?>
    @toastr_css
<?php $__env->startSection('title'); ?>
    <?php echo e(trans('main_trans.students')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<div class="page-title">
    <div class="row">
        <div class="col-sm-6">
            <h4 class="mb-0"><?php echo e(trans('main_trans.students')); ?></h4>
        </div>
        <div class="col-sm-6">
            <ol class="breadcrumb pt-0 pr-0 float-left float-sm-right ">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>" class="default-color"><?php echo e(trans('main_trans.main')); ?></a></li>
                <li class="breadcrumb-item active"><?php echo e(trans('main_trans.students')); ?></li>
            </ol>
        </div>
    </div>
</div>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- row -->
    <div class="row">
        <div class="col-md-12 mb-30">
            <div class="card card-statistics h-100">
                <div class="card-body">
                    <div class="col-xl-12 mb-30">
                        <div class="card card-statistics h-100">
                            <div class="card-body">
                                <a href="<?php echo e(route('students.create')); ?>" class="btn btn-success btn-lg" role="button"
                                   aria-pressed="true"><?php echo e(trans('main_trans.Add_student')); ?></a><br><br>
                                <div class="table">
                                    <table id="datatable" class="table  table-hover table-sm table-bordered p-0"
                                           data-page-length="50"
                                           style="text-align: center">
                                        <thead>
                                        <tr>
                                            <th>#</th>
                                            <th><?php echo e(trans('students_trans.name')); ?></th>
                                            <th><?php echo e(trans('students_trans.email')); ?></th>
                                            <th><?php echo e(trans('students_trans.gender')); ?></th>
                                            <th><?php echo e(trans('students_trans.Grade')); ?></th>
                                            <th><?php echo e(trans('students_trans.classrooms')); ?></th>
                                            <th><?php echo e(trans('students_trans.section')); ?></th>
                                            <th><?php echo e(trans('students_trans.Processes')); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                            <td><?php echo e($loop->index+1); ?></td>
                                            <td><?php echo e($student->name); ?></td>
                                            <td><?php echo e($student->email); ?></td>
                                            <td><?php echo e($student->gender->name); ?></td>
                                            <td><?php echo e($student->level->name); ?></td>
                                            <td><?php echo e($student->classroom->name); ?></td>
                                            <td><?php echo e($student->section->name); ?></td>
                                                <td>
                                                    <div class="dropdown show">
                                                        <a class="btn btn-success btn-sm dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                            <?php echo e(trans('students_trans.Processes')); ?>

                                                        </a>
                                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                                            <a class="dropdown-item" href="<?php echo e(route('students.show',$student->id)); ?>"><i style="color: #ffc107" class="far fa-eye "></i>&nbsp;  <?php echo e(trans('students_trans.show_student')); ?></a>
                                                            <a class="dropdown-item" href="<?php echo e(route('students.edit',$student->id)); ?>"><i style="color:green" class="fa fa-edit"></i>&nbsp;  <?php echo e(trans('students_trans.Student_Edit')); ?></a>
                                                            <a class="dropdown-item" href="<?php echo e(route('fees_student.show',$student->id)); ?>"><i style="color: #0000cc" class="fa fa-edit"></i>&nbsp; <?php echo e(trans('fee_trans.add_fee')); ?>&nbsp;</a>
                                                            <a class="dropdown-item" href="<?php echo e(route('receipt_students.show',$student->id)); ?>"><i style="color: #9dc8e2" class="fas fa-money-bill-alt"></i>&nbsp; &nbsp; <?php echo e(trans('fee_trans.add_receipt')); ?></a>
                                                            <a class="dropdown-item" href="<?php echo e(route('processing_fee.show',$student->id)); ?>"><i style="color: #61e07b" class="fas fa-money-bill-alt"></i>&nbsp; &nbsp; <?php echo e(trans('fee_trans.add_exclude')); ?></a>
                                                            <a class="dropdown-item" href="<?php echo e(route('payment_students.show',$student->id)); ?>"><i style="color:goldenrod" class="fas fa-donate"></i>&nbsp; &nbsp; <?php echo e(trans('fee_trans.add_exchange')); ?></a>
                                                            <a class="dropdown-item" data-target="#Delete_Student<?php echo e($student->id); ?>" data-toggle="modal" href="##Delete_Student<?php echo e($student->id); ?>"><i style="color: red" class="fa fa-trash"></i>&nbsp;  <?php echo e(trans('students_trans.Deleted_Student')); ?></a>
                                                            <a class="dropdown-item" href="<?php echo e(route('students.graduated',$student->id)); ?>"> <i style="color:green" class="fas fa-glasses"></i>&nbsp;<?php echo e(trans('students_trans.gradustion')); ?></a>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php echo $__env->make('DashboardAdmin.students.Delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    @toastr_js
    @toastr_render
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\laravel\School_System\resources\views/DashboardAdmin/students/index.blade.php ENDPATH**/ ?>
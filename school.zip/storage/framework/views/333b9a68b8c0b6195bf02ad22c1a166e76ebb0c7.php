<?php $__env->startSection('css'); ?>
<?php $__env->startSection('title'); ?>
<?php echo e(trans('main_trans.study_fees')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">
    <div class="col-md-12 mb-30">
        <div class="card card-statistics h-100">
            <div class="card-body">
                <div class="col-xl-12 mb-30">
                    <div class="card card-statistics h-100">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="datatable" class="table  table-hover table-sm table-bordered p-0"
                                       data-page-length="50"
                                       style="text-align: center">
                                    <thead>
                                    <tr class="alert-success">
                                        <th>#</th>
                                        <th><?php echo e(trans('fee_trans.name')); ?></th>
                                        <th><?php echo e(trans('fee_trans.Fee_type')); ?></th>
                                        <th><?php echo e(trans('fee_trans.amount')); ?></th>
                                        <th><?php echo e(trans('fee_trans.level')); ?></th>
                                        <th><?php echo e(trans('fee_trans.classroom')); ?></th>
                                        <th><?php echo e(trans('fee_trans.statement')); ?></th>
                                        <th><?php echo e(trans('fee_trans.Processes')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $Fee_invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Fee_invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($Fee_invoice->student->name); ?></td>
                                        <td><?php echo e($Fee_invoice->fee->title); ?></td>
                                        <td><?php echo e(number_format($Fee_invoice->amount, 2)); ?></td>
                                        <td><?php echo e($Fee_invoice->level->name); ?></td>
                                        <td><?php echo e($Fee_invoice->classroom->name); ?></td>
                                        <td><?php echo e($Fee_invoice->description); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('sons.receipt',$Fee_invoice->student_id)); ?>" title="Payments" class="btn btn-info btn-lg" role="button" aria-pressed="true"><i class="fa fa-edit"></i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- row closed -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.parent.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\laravel\School_System\resources\views/DashboardParent/fees/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('css'); ?>
    @toastr_css
<?php $__env->startSection('title'); ?>
<?php echo e(trans('fee_trans.add_fee')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<div class="page-title">
    <div class="row">
        <div class="col-sm-6">
            <h4 class="mb-0"><?php echo e(trans('fee_trans.add_fee')); ?></h4>
        </div>
        <div class="col-sm-6">
            <ol class="breadcrumb pt-0 pr-0 float-left float-sm-right ">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>" class="default-color"><?php echo e(trans('main_trans.main')); ?></a></li>
                <li class="breadcrumb-item active"><?php echo e(trans('fee_trans.add_fee')); ?></li>
            </ol>
        </div>
    </div>
</div>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- row -->
    <div class="row">
        <div class="col-md-12 mb-30">
            <div class="card card-statistics h-100">
                <div class="card-body">

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form method="post" action="<?php echo e(route('fees.store')); ?>" autocomplete="off">
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="form-group col">
                                <label for="inputEmail4"><?php echo e(trans('fee_trans.name_ar')); ?></label>
                                <input type="text" value="<?php echo e(old('title')); ?>" name="title" class="form-control">
                            </div>

                            <div class="form-group col">
                                <label for="inputEmail4"><?php echo e(trans('fee_trans.name_en')); ?></label>
                                <input type="text" value="<?php echo e(old('title_en')); ?>" name="title_en" class="form-control">
                            </div>


                            <div class="form-group col">
                                <label for="inputEmail4"><?php echo e(trans('fee_trans.amount')); ?></label>
                                <input type="number" value="<?php echo e(old('amount')); ?>" name="amount" class="form-control">
                            </div>
                        </div>


                        <div class="form-row">

                            <div class="form-group col">
                                <label for="inputState"><?php echo e(trans('fee_trans.level')); ?></label>
                                <select class="custom-select mr-sm-2" name="level_id">
                                    <option selected disabled><?php echo e(trans('Parent_trans.Choose')); ?>...</option>
                                    <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($level->id); ?>"><?php echo e($level->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group col">
                                <label for="inputZip"><?php echo e(trans('fee_trans.classroom')); ?></label>
                                <select class="custom-select mr-sm-2" name="classroom_id">

                                </select>
                            </div>
                            <div class="form-group col">
                                <label for="inputZip"><?php echo e(trans('fee_trans.academic_year')); ?></label>
                                <select class="custom-select mr-sm-2" name="year">
                                    <option selected disabled><?php echo e(trans('Parent_trans.Choose')); ?>...</option>
                                    <?php
                                        $current_year = date("Y")
                                    ?>
                                    <?php for($year=$current_year; $year<=$current_year +1 ;$year++): ?>
                                        <option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>

                            <div class="form-group col">
                                <label for="inputZip"><?php echo e(trans('fee_trans.Fee_type')); ?></label>
                                <select class="custom-select mr-sm-2" name="fee_type">
                                    <option value="1"><?php echo e(trans('fee_trans.Tuition_fees')); ?></option>
                                    <option value="2"><?php echo e(trans('fee_trans.bus_fee')); ?></option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="inputAddress"><?php echo e(trans('fee_trans.Notes')); ?></label>
                            <textarea class="form-control" name="description" id="exampleFormControlTextarea1" rows="4"></textarea>
                        </div>
                        <br>

                        <button type="submit" class="btn btn-primary btn-lg"><?php echo e(trans('fee_trans.submit')); ?></button>

                    </form>

                </div>
            </div>
        </div>
    </div>
    <!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    @toastr_js
    @toastr_render
    <script>
        function CheckAll(classroom, elem) {
            var elements = document.getElementsByClassName(classroom);
            var l = elements.length;
            if (elem.checked) {
                for (var i = 0; i < l; i++) {
                    elements[i].checked = true;
                }
            } else {
                for (var i = 0; i < l; i++) {
                    elements[i].checked = false;
                }
            }
        }
    </script>
    <script>
        $(document).ready(function () {
            $('select[name="level_id"]').on('change', function () {
                var level_id = $(this).val();
                if (level_id) {
                    $.ajax({
                        url: "<?php echo e(URL::to('Get_classrooms')); ?>/" + level_id,
                        type: "GET",
                        dataType: "json",
                        success: function (data) {
                            $('select[name="classroom_id"]').empty();
                            $('select[name="classroom_id"]').append('<option selected disabled ><?php echo e(trans('parent_trans.Choose')); ?>...</option>');
                            $.each(data, function (key, value) {
                                $('select[name="classroom_id"]').append('<option value="' + key + '">' + value + '</option>');
                            });
                        },
                    });
                }
                else {
                    console.log('AJAX load did not work');
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\laravel\School_System\resources\views/fees/create.blade.php ENDPATH**/ ?>
<?php $__env->startSection('css'); ?>
    @toastr_css
<?php $__env->startSection('title'); ?>
    <?php echo e(trans('level_trans.title_page')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<div class="page-title">
    <div class="row">
        <div class="col-sm-6">
            <h4 class="mb-0"><?php echo e(trans('main_trans.School Level List')); ?></h4>
        </div>
        <div class="col-sm-6">
            <ol class="breadcrumb pt-0 pr-0 float-left float-sm-right ">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>" class="default-color"><?php echo e(trans('main_trans.main')); ?></a></li>
                <li class="breadcrumb-item active"><?php echo e(trans('main_trans.School Level List')); ?></li>
            </ol>
        </div>
    </div>
</div>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- row -->
    <div class="row">

        <div class="col-xl-12 mb-30">
            <div class="card card-statistics h-100">
                <div class="card-body">

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <button type="button" class="button x-small" data-toggle="modal" data-target="#exampleModal">
                        <?php echo e(trans('level_trans.add-level')); ?>

                    </button>
                    <br><br>

                    <div class="table-responsive">
                        <table id="datatable" class="table  table-hover table-sm table-bordered p-0"
                               data-page-length="50"
                               style="text-align: center">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th><?php echo e(trans('level_trans.Name_level')); ?></th>
                                <th><?php echo e(trans('level_trans.Notes')); ?></th>
                                <th><?php echo e(trans('level_trans.Processes')); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $i = 0; ?>
                            <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php $i++; ?>
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e($level->name); ?></td>
                                    <td><?php echo e($level->notes); ?></td>
                                    <td>
                                        <button type="button" class="btn btn-info btn-sm" data-toggle="modal"
                                                data-target="#edit<?php echo e($level->id); ?>"
                                                title="<?php echo e(trans('level_trans.Edit')); ?>"><i
                                                class="fa fa-edit"></i></button>
                                        <button type="button" class="btn btn-danger btn-sm" data-toggle="modal"
                                                data-target="#delete<?php echo e($level->id); ?>"
                                                title="<?php echo e(trans('level_trans.Delete')); ?>"><i
                                                class="fa fa-trash"></i></button>
                                    </td>
                                </tr>

                                <!-- edit_modal_Grade -->
                                <div class="modal fade" id="edit<?php echo e($level->id); ?>" tabindex="-1" role="dialog"
                                     aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title"
                                                    id="exampleModalLabel">
                                                    <?php echo e(trans('level_trans.edit_level')); ?>

                                                </h5>
                                                <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <!-- add_form -->
                                                <form action="<?php echo e(route('levels.update',$level->id)); ?>" method="POST">
                                                    <?php echo e(method_field('patch')); ?>

                                                    <?php echo csrf_field(); ?>
                                                    <div class="row">
                                                        <div class="col">
                                                            <label for="name"
                                                                   class="mr-sm-2"><?php echo e(trans('level_trans.Name_class')); ?>

                                                                :</label>
                                                            <input id="name" type="text" name="name"
                                                                   class="form-control"
                                                                   value="<?php echo e($level->getTranslation('name', 'ar')); ?>"
                                                                   >
                                                            <input id="id" type="hidden" name="id" class="form-control"
                                                                   value="<?php echo e($level->id); ?>">
                                                        </div>
                                                        <div class="col">
                                                            <label for="name_en"
                                                                   class="mr-sm-2"><?php echo e(trans('level_trans.Name_class_en')); ?>

                                                                :</label>
                                                            <input type="text" class="form-control"
                                                                   value="<?php echo e($level->getTranslation('name', 'en')); ?>"
                                                                   name="name_en" >
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label
                                                            for="exampleFormControlTextarea1"><?php echo e(trans('level_trans.Notes')); ?>

                                                            :</label>
                                                        <textarea class="form-control" name="notes"
                                                                  id="exampleFormControlTextarea1"
                                                                  rows="3"><?php echo e($level->notes); ?></textarea>
                                                    </div>
                                                    <br><br>

                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                                data-dismiss="modal"><?php echo e(trans('level_trans.Close')); ?></button>
                                                        <button type="submit"
                                                                class="btn btn-success"><?php echo e(trans('level_trans.submit')); ?></button>
                                                    </div>
                                                </form>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- delete_modal_level -->
                                <div class="modal fade" id="delete<?php echo e($level->id); ?>" tabindex="-1" role="dialog"
                                     aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title"
                                                    id="exampleModalLabel">
                                                    <?php echo e(trans('level_trans.Delete')); ?>

                                                </h5>
                                                <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <form action="<?php echo e(route('levels.destroy',$level->id)); ?>" method="post">
                                                    <?php echo e(method_field('Delete')); ?>

                                                    <?php echo csrf_field(); ?>
                                                    <?php echo e(trans('level_trans.Warning_level')); ?>

                                                    <input id="id" type="hidden" name="id" class="form-control"
                                                           value="<?php echo e($level->id); ?>">
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                                data-dismiss="modal"><?php echo e(trans('level_trans.Close')); ?></button>
                                                        <button type="submit"
                                                                class="btn btn-danger"><?php echo e(trans('level_trans.submit')); ?></button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>


        <!-- add_modal_level -->
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog"
             aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title"
                            id="exampleModalLabel">
                            <?php echo e(trans('level_trans.add-level')); ?>

                        </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <!-- add_form -->
                        <form action="<?php echo e(route('levels.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col">
                                    <label for="name"
                                           class="mr-sm-2"><?php echo e(trans('level_trans.Name_class')); ?>

                                        :</label>
                                    <input id="name" type="text" name="name" class="form-control">
                                </div>
                                <div class="col">
                                    <label for="name_en"
                                           class="mr-sm-2"><?php echo e(trans('level_trans.Name_class_en')); ?>

                                        :</label>
                                    <input type="text" class="form-control" name="name_en" >
                                </div>
                            </div>
                            <div class="form-group">
                                <label
                                    for="exampleFormControlTextarea1"><?php echo e(trans('level_trans.Notes')); ?>

                                    :</label>
                                <textarea class="form-control" name="notes" id="exampleFormControlTextarea1"
                                          rows="3"></textarea>
                            </div>
                            <br><br>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary"
                                data-dismiss="modal"><?php echo e(trans('level_trans.Close')); ?></button>
                        <button type="submit"
                                class="btn btn-success"><?php echo e(trans('level_trans.submit')); ?></button>
                    </div>
                    </form>

                </div>
            </div>
        </div>

    </div>

    <!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    @toastr_js
    @toastr_render
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\laravel\School_System\resources\views/levels/index.blade.php ENDPATH**/ ?>
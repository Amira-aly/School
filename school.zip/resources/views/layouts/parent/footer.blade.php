<!-- ======= Footer ======= -->
<footer id="footer">
    <div class="container">
      <div class="social-links">
        <a href="#" class="twitter"><i class="fab fa-twitter"></i></a>
        <a href="#" class="facebook"><i class="fab fa-facebook"></i></a>
        <a href="#" class="instagram"><i class="fab fa-instagram"></i></a>
        <a href="#" class="google-plus"><i class="fab fa-skype"></i></a>
        <a target="_blank" href="https://www.linkedin.com/in/amiraaly99/" class="linkedin"><i class="fab fa-linkedin"></i></a>
      </div>
      <div class="copyright">
        &copy; Copyright <strong><span>AL School</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        Designed by <a target="_blank" href="https://github.com/Amira-aly">Amira Ali</a>
      </div>
    </div>
  </footer><!-- End Footer -->

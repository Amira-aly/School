<nav class="navbar navbar-expand-lg navbar-light " style="padding-left: 10px; background: #8f98c6;">
    <h2 class="text-light" style="margin: 1%;"><a href="{{route('home')}}" style="font-size: x-large;">AL School</a></h2>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="nav navbar-nav ml-auto ">
            <li class="nav-item ">
              <a class="nav-link" href="" style="color: beige; font-size: large;padding-right: 28px;">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link " href="" style="color: beige; font-size: large;padding-right: 28px;">About</a>
            </li>
            <li class="nav-item">
                <a class="nav-link " href="" style="color: beige; font-size: large;">Contact US</a>
            </li>
        </ul>

    </div>
  </nav>

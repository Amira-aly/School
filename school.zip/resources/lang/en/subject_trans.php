<?php
return [
    'add_subject' => 'Add Subject',
    'subject_name' => 'Subject Name',
    'level' => 'Level',
    'classroom' => 'Classroom',
    'Name_Teacher' => 'Name Teacher',
    'Processes' => 'Processes',
    'Close' => 'Close',
    'submit' => 'Submit',
    'Delete' => 'Delete',
    'Warning_subject'=> 'Do you Delete Subject ?',
    'name_ar' => 'Subject Name Arabic',
    'name_en' => 'Subject Name English',
    'Choose' => 'Choose',
    'edit' => 'Edit Data',
];

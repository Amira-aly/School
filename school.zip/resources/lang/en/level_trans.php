<?php

return [
    'add-level' => 'Add Level',
    'Name_class'=> 'Name Level Arabic',
    'Name_class_en'=> 'Name Level English',
    'Name_level' => 'Name Level',
    'Processes' => 'Processes',
    'Edit' => 'Edit',
    'Delete' => 'Delete',
    'edit_level' => 'Edite Level',
    'Notes' => 'Notes',
    'Close' => 'Close',
    'submit' => 'Submit',
    'Warning_level'=> 'Do you Delete Level ?',
    'add_row' => 'Add New Level',
    'existss' => 'This field already exists',
    'delete_level_Error' => 'It is not possible to delete the stage because there are rows belonging to it',
    'Section' => 'sections'

];

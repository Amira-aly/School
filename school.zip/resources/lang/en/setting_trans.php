<?php
return [
    'school_name' => 'School Name',
    'current_year' => 'Current Year',
    'short_name' =>'Short Name School',
    'phone' => 'Phone',
    'email' => 'Email',
    'address' => 'School Address',
    'end_first_term' => 'End Term One',
    'end_second_term' => 'End Term Second',
    'logo' => 'School Logo',
    'submit' => 'Submit'

];

<?php

return [
    'success'=>'Data has been saved successfully',
    'Update'=>'Data has been Updated successfully',
    'Delete'=>'Data has been Deleted successfully',
    'required' => 'This field must be entered',
    'unique' => 'This field already exists'

];

<?php

return [
    'add_fee' => 'Add Tuition Fees',
    'name' => 'Name',
    'name_ar' => 'Name Fee Arbic',
    'name_en' => 'Name Fee English',
    'amount' => 'Amount',
    'level' => 'Level',
    'classroom' => 'Classroom',
    'academic_year' => 'Academic Year',
    'Notes' => 'Notes',
    'Processes'=>'Processes',
    'Delete' => 'Delete',
    'Deleted_fee' => 'Delete Fee',
    'Close' => 'Close',
    'submit' => 'Submit',
    'Warning_fee'=> 'Do you Delete Fee ?',
    'Fee_type' => 'Fee Type',
    'Tuition_fees' => 'Tuition Fees',
    'bus_fee' => 'Bus Fee',
    'edit' => 'Edit Data',
    'editt' => 'Tuition Fee Adjustment',
    'add_fee' => 'Add Student Fees',
    'add_row' => 'Add Fee New',
    'Invoices' => 'Invoices',
    'receipt' => 'Receipt Voucher',
    'exclude' => 'Exclude Fee',
    'exchange' => 'Exchange Stats',
    'statement' => 'Statement',
    'name_student' => 'Name Student',
    'delete_fee' => 'Delete Invoice',
    'Choose' => 'Choose',
    'edit_exchange' => 'Edit Exchange',
    'add_exchange' => 'Add Exchange',
    'student_credit' => 'Student Credit',
    'delete_exchange' => 'Delete Exchange',
    'add_exclude' => 'Add Exclude Fee',
    'add_receipt' => 'Add Receipt',
    'tuition_processors' => 'Tuition Fee Processors',
    'edit_processors' => 'Edit Tuition Fee Processors',
    'edit_receipt' => 'Edit Receipt',
    'delete_receipt' => 'Delete Receipt',
    'invoice_date' => 'Invoice Date'







];

<?php
return [
    'profile' => 'Profile personly',
    'user_name' => 'User Name',
    'password' => 'Password',
    'show_password' => 'Show Password',
    'edit' => 'Edit Data',
    'email' => 'Email'
];

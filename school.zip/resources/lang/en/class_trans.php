<?php

return [
    'add_row' => 'Add Classroom',
    'delete_row' => 'Delete Classroom',
    'Processes'=>'Processes',
    'Namelevel' => 'Name Level',
    'name_class_en' => 'Name Classroom English',
    'name_class' => 'Name Classroom Arabic',
    'add_class' => 'Add Classroom',
    'Close' => 'Close',
    'submit' => 'Submit',
    'Delete' => 'Delete',
    'delete_class' => 'Delete Classroom',
    'stage_name_en' => 'Name Classroom English',
    'stage_name_ar' => 'Name Classroom Arabic',
    'name_classs' => 'Name Classroom',
    'title_page' => 'Classrooms',
    'Notes' => 'Notes',
    'Warning_level'=> 'Do you Delete Classroom ?',
    'Edit' => 'Edit',
    'add_row' => 'Add New Level',
    'existss' => 'This field already exists',
    'delete_checkbox' => 'Delete the selected rows',
    'Search_By_level' => 'Search by grade level'

];

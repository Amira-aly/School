<?php
return [
    'add_book' => 'Add Book',
    'name' => 'Book Name',
    'level' => 'Level',
    'classroom' => 'Classroom',
    'section' => 'Section',
    'Choose' => 'Choose',
    'attachments' => 'Attachments',
    'Processes' => 'Processes',
    'Close' => 'Close',
    'submit' => 'Submit',
    'Delete' => 'Delete',
    'Warning_library'=> 'Do you Delete Library ?',
    'delete_book' => 'Delete Book',
    'edit_book' => 'Edit Book',
    'edit' => 'Edit Data',
    'Name_Teacher' => 'Name Teacher',
    'Download' => 'Download Book'

];

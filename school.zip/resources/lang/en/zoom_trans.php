<?php
return [
    'add_zoom' => 'Add A Class',
    'level' => 'Level',
    'classroom' => 'Classroom',
    'section' => 'Section',
    'Choose' => 'Choose',
    'topic' => 'Class Title',
    'start_time' => 'Class Date And Time',
    'duration' => 'Class Duration In Minutes',
    'Processes' => 'Processes',
    'Close' => 'Close',
    'submit' => 'Submit',
    'Delete' => 'Delete',
    'Warning_zoom'=> 'Do you Delete Class ?',
    'online' => 'Online Classes',
    'add_online_zoom' => 'Add A New Online Share',
    'add_offline_zoom' => 'Add A New Offline Share',
    'Name_Teacher' => 'Name Teacher',
    'link' => 'Share Link',
    'join' => 'Join Now',
    'meeting_id' => 'Meeting ID',
    'meeting_password' => 'Meeting Password',
    'Link_login' => 'Link To Login For Students',
    'all_meeting' => 'All Meetings'

];

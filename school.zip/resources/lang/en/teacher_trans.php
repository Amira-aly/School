<?php

return [
    'Name_Teacher'=>'Name Teacher',
    'Add_Teacher'=>'Add Teacher',
    'Edit_Teacher'=>'Edit Teacher',
    'Delete_Teacher'=>'Delete Teacher',
    'Email'=>'Email',
    'Password'=>'Password',
    'Name_ar'=>'Name Arbic',
    'Name_en'=>'Name English',
    'specialization'=>'specialization',
    'Gender'=>'Gender',
    'Joining_Date'=>'Joining_Date',
    'Address'=>'Address',
    'Close' => 'Close',
    'submit' => 'Submit',
    'Delete' => 'Delete',
    'Warning_teacher'=> 'Do you Delete Teacher ?',
    'Processes'=>'Processes',

];

<?php
return [
    'school_name' => 'اسم المدرسة',
    'current_year' => 'العام لحالي',
    'short_name' => 'اسم المدرسة المختصر',
    'phone' => 'الهاتف',
    'email' => 'البريد الالكترونى',
    'address' => 'عنوان المدرسة',
    'end_first_term' => 'نهاية الترم الاول',
    'end_second_term' => 'نهاية الترم التاني',
    'logo' => 'شعار المدرسة',
    'submit' => 'حفظ البيانات'
];

<?php

return [
    'Name_Teacher'=>'اسم المعلم',
    'Add_Teacher'=>'اضافة معلم',
    'Edit_Teacher'=>'تعديل معلم',
    'Delete_Teacher'=>'حذف معلم',
    'Email'=>'البريد الالكتروني',
    'Password'=>'كلمة المرور',
    'Name_ar'=>'اسم المعلم باللغة العربية',
    'Name_en'=>'اسم المعلم باللغة الانجليزية',
    'specialization'=>'التخصص',
    'Gender'=>'النوع',
    'Joining_Date'=>'تاريخ التعين',
    'Address'=>'العنوان',
    'Close' => 'اغلاق',
    'submit' => 'حفظ البيانات',
    'Delete' => 'حذف',
    'Warning_teacher'=> 'هل انت متاكد من عملية الحذف ؟',
    'Processes'=>'العمليات',

];

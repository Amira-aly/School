<?php
return [
    'add_book' => 'اضافة كتاب',
    'name' => 'اسم الكتاب',
    'level' =>  'المرحلة الدراسية',
    'classroom' => 'الصف الدراسية',
    'section' => 'القسم',
    'Choose' => 'اختيار من القائمة',
    'attachments' => 'المرفقات',
    'Processes' => 'العمليات',
    'Close' => 'اغلاق',
    'submit' => 'حفظ البيانات',
    'Delete' => 'حذف',
    'Warning_library' => 'هل انت متاكد من عملية الحذف ؟',
    'delete_book' => 'حذف الكتاب',
    'edit_book' => 'تعديل كتاب',
    'edit' => 'تعديل البيانات',
    'Name_Teacher' => 'اسم المعلم',
    'Download' => 'تحميل الكتاب'

];

<?php
return [
    'add_zoom' => 'اضافة حصة جديدة',
    'level' =>  'المرحلة الدراسية',
    'classroom' => 'الصف الدراسية',
    'section' => 'القسم',
    'Choose' => 'اختيار من القائمة',
    'topic' => 'عنوان الحصة',
    'start_time' => 'تاريخ ووقت الحصة',
    'duration' => 'مدة الحصة بالدقائق',
    'Processes' => 'العمليات',
    'Close' => 'اغلاق',
    'submit' => 'حفظ البيانات',
    'Delete' => 'حذف',
    'Warning_zoom' => 'هل انت متاكد من عملية الحذف ؟',
    'online' => 'حصص اونلاين',
    'add_online_zoom' => 'اضافة حصة اونلاين',
    'add_offline_zoom' => 'اضافة حصة اوفلاين',
    'Name_Teacher' => 'اسم المعلم',
    'link' => 'رابط الحصة',
    'join' => 'انضم الان',
    'meeting_id' => 'رقم الخاص بالاجتماع',
    'meeting_password' => 'كلمة مرور الاجتماع',
    'Link_login' => 'لينك الدخول للطلاب',
    'all_meeting' => 'كل الاجتماعات'

];

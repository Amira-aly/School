<?php

return[
    'fallback_locale' => 'en'

];

<?php return array (
  'addparent' => 'App\\Http\\Livewire\\Addparent',
  'calendar' => 'App\\Http\\Livewire\\Calendar',
  'show-question' => 'App\\Http\\Livewire\\ShowQuestion',
  'studen-calendar' => 'App\\Http\\Livewire\\StudenCalendar',
);